import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner Scanner = new Scanner(System.in);

    int a = Scanner.nextInt();
    int b = Scanner.nextInt();
    int c = Scanner.nextInt();

   double e = Math.sqrt((b*b)-4*a*c);
    double e1 = ((-b + e)/2*a);
    double e2 = ((-b - e)/2*a);
    
    System.out.println("answer1"+ e1);
    System.out.println("answer2"+e2);

    }
}