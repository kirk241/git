
import java.util.Scanner;
public class Main {
  public static void main(String[] args) {
    Scanner Scanner = new Scanner(System.in);
    int a = Scanner.nextInt();
        int [] sequence = new int[a];
    
        sequence[1] = 1;

        for(int i = 2;i<a;i++){
            sequence[i] = sequence[i - 1] + sequence[i - 2];
        }

        for(int i = 0;i<a;i++){
            System.out.println(sequence[i]);
        }
    }
}