import java.util.Scanner;
public class Main {
  public static void main(String[] args) {
    }
    Scanner Scanner = new Scanner(System.in);

    int a  = Scanner.nextInt();
    System.out.println("type a number:"+a);
    int b = i% 3;
    int c = i % 5;
     for(int i = 0;i<a;i++){
       if (b == 0) {
      System.out.println(Fizz);
      }
     else if ( c == 0) {
         System.out.println(buzz);
    }
     else if (b == 0 & c == 0) {
         System.out.println(Fizzbuzz);
    }
        else {
           System.out.println(i);
    
       
      }
    }
    }
